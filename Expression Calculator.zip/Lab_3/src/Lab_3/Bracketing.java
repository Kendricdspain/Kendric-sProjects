
package Lab_3;
//http://www.dcs.gla.ac.uk/~daw/books/JC/code/ch06/


public class Bracketing {

public static boolean wellBracketed (String phrase) {
    // Test whether phrase is well-bracketed.
  //  FixedStack bracketStack = new FixedStack(50);
    LinkedStack bracketStack = new LinkedStack();
    for (int i = 0; i < phrase.length(); i++) {
        char cur = phrase.charAt(i);
        if (cur == '(' || cur == '[' || cur == '{')
            bracketStack.push(""+cur);
        else if (cur == ')' || cur == ']' || cur == '}') {
            if (bracketStack.isEmpty()) return false;
            char left = bracketStack.pop().charAt(0);
            if (! matched(left, cur)) return false;
        }
    }
    return (bracketStack.isEmpty());
}

public static boolean matched (char left, char right) {
    // Test whether left and right are matching brackets
    // (assuming that left is a left bracket and right is a right bracket).
    switch (left) {
        case '(':
            return (right == ')');
        case '[':
            return (right == ']');
        case '{':
            return (right == '}');
    }
    return false;
}

public static void main (String[] args) {
    
        String phrase = "(( 4 + 4 ) / 5)";
        System.out.println(phrase + " is " );
        Bracketing b = new Bracketing();
        System.out.println(phrase + " is "
                + (b.wellBracketed(phrase) ? "well" : "ill")
                + "-bracketed.");
    
}

}
