package Lab_3;
/* Author  Antonio Sanchez.
 *  
 * Last modification	: Jan 2019           
 * Element for a single ptr
   based on an extension to the code of Narasimha Karumanchi 
 *     in  Structures And Algorithms Made In Java
 
 */



public class ElementSPtr 
{   private  ElementSPtr next;
	private  String value;
	
	
	public ElementSPtr () 
	       { value = ""; next = null; }
    public ElementSPtr(String v ) 
    {  next = null; value = v; }
    
     public void setValue(String v)		
	{   value =  v; }
	public String getValue()		
	{ return value; }
	// Returns the node that follows this one.
	public ElementSPtr getNext(){ return next; }
    // Sets the node that follows this one.
    public void setNext (ElementSPtr n){next = n; }
	
}
