package Lab_3;




import java.util.Scanner;

import javax.swing.JButton;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;



public class BTLinked implements BTModel{
    private ElementBTPtr root;
    private BTMethods wbt;
    private Lab_3Model c;
    
    //private BTMethods2 wbt2;
   // private String[] list;
    
    private final boolean verbose = true;
    public BTLinked(Lab_3Model fromC) {
    	c = fromC;
    // Construct a text, initially empty.
      
       // root = new ElementBTPtr();
        wbt = new BTMethods(root);
    
     }
    /*public void printPath()
    {   c.console.append("\nFound Paths\n");
        wbt.printPaths(root, c.console); 
    }*/
   
    
    
    public void loadTree()
    {  //String file = c.paramTF[1].getText();
       //root = wbt.loadTree(file);
       
    }
   
    public void draw(){
    StringTree t = new StringTree(); // t is Binary tree we are displaying
    t.root = root;
    //t.root = wbt.temp;
    t.computeNodePositions(); //finds x,y positions of the tree nodes
    t.maxheight=t.treeHeight(t.root); //finds tree height for scaling y axis
    System.out.println( " root "+ t.root.getValue() + " S " + t.inputString);
    DisplaySimpleTree dt = new DisplaySimpleTree(t);//get a display panel
    dt.setVisible(true); //show the display
  }
   
   /* public void saveTree()
    {  String file = c.paramTF[1].getText();
        wbt.saveTree(root, file);
       
    }*/
    
    
    public void insert(String value) {
    	  //String value = c.paramTF[1].getText();
    	  root = wbt.insert(root, value);
        
    }
    
    public void numberNodes() {
  	  // c.paramTF[0].setText(""+wbt.numberOfNodes(root));
  	  
      
  }
    public void reverse() {
  	  root = wbt.reverse(root);
     
  }
    public void copy() {
   
    	root = wbt.copy(root);
    	//c.console.append("  COPY of current tree \n");
    	//c.console.append("  prefix [ " + wbt.display(root,'p') +"]\n");
    	}
  
    public void addBT() {
    	
//    	c.console.append("  String for current tree \n");
//    	c.console.append(wbt.addBT(root) +"\n");
    	}
    
    public void reverseInPlace() {
    	   
    	root = wbt.reverseInPlace(root);
//    	c.console.append("  REVERSE in place\n");
//    	c.console.append("  prefix [ " + wbt.display(root,'p') +"]\n");
    	}
    public void clear() {
//    	c.console.setText("");
    	root = null;
    
      
  }
    public void findInTree() {
//    	  String value = c.paramTF[1].getText();
//    	  c.paramTF[1].setText(""+ wbt.findInBT(root, value));
    	  
        
    }
    public void traverse(char opt) {
 	   switch (opt) 
 	   { case 'p' : wbt.preFix(root); break;
 	     case 'i' : wbt.inFix(root); break;
 	     case 'r' : wbt.postFix(root); break;
 	   }    
      }
    
     
     public void displayTree() {
//    	        c.console.append("Current Tree");
//    	        c.console.append("  in PREFIX [\n " + wbt.display(root,'p') +"]");
    	        System.out.print("  in PREFIX [ " + wbt.display(root,'p') +"]");
    	       // c.console.append(" in INFIX [\n " + wbt.display(root,'i') +"]");
    	       // System.out.print("  in INFIX [ " + wbt.display(root,'i') +"]");
    	        // c.console.append(" in POSTFIX [\n " + wbt.display(root,'r') +"]"); 
    	       // System.out.print("  in POSTFIX [ " + wbt.display(root,'r') +"]");
     }
       
     
     
     private void warn (String msg) {
         System.out.println("WARNING: " + msg);
     }

     public void QUIT() {
         //
       	System.out.println(" Quitting Right Now ");
     	    System.exit(1);
         }
    
     public void width()
     {  
       // c.console.append("\nWidth of Tree "+ +wbt.width(root));
        
     } 
     public void minDepth()
     {  
       // c.console.append("\nMinimum Depth of Tree "+ +wbt.minDepth(root));
        
     } 
     public void maxDepth()
     {  
      //  c.console.append("\nMaximum Depth of Tree "+ +wbt.maxDepthRecursive(root));
        
     }
    
     
     public void loadLevel()
     {  //String v = c.paramTF[1].getText();
        //root = wbt2.loadTreeOrder(v);
        
     }
     public void insertLevel()
     {  //String v = c.paramTF[1].getText();
        //root = wbt2.insertInBinaryTreeLevelOrder(root, v);
        
     }
     /*public void searchLevel()
     {  String v = c.paramTF[1].getText();
        c.paramTF[1].setText(""+wbt2.SearchBinaryTreeLevelOrder(root,v));
        
     }*/
     public void deepest()
     { //root= wbt2.deepestNode(root);
       //c.console.append("\nDeepest Leaf [ " + wbt.display(root,'p') +"]\n");
     }
     public void diameter()
     { 
       //c.console.append("\nDiameter of Tree " + wbt2.diameterOfTree(root));
     }
     public void largest()
     { 
      // c.console.append("\nLargest String of Tree " + wbt2.largestString(root));
     }
     
     

 }
