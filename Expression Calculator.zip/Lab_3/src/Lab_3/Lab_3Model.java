package Lab_3;

import javax.swing.*;



import java.awt.*;
import java.io.File;
import java.io.FileInputStream;
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 * this class creates the methods needed to open a file, draw the tree of a BT, quit, clear,
 * number of nodes, set variable, infix to post fix, and read expression.
 * 
 * @author kendricdspain
 * code altered by Kendric D'spain and written by Dr. Sanchez at TCU. 
 */
public class Lab_3Model 
{
	
	//BTLinked BTL = new BTLinked();
	String root = "";
	FLStack reversedStack = new LinkedStack();
	ElementBTPtr BTPtr;
	private BTModel m;
	private Lab_3Control c;
	private Lab_3View v;
	private InToPost theTrans;
	public int stackSize;
	private PostfixEvaluator  pe = new PostfixEvaluator(this);
	int numberOfNodes = 0;
	String pos = "";
	Boolean verbose = false;
public Lab_3Model() {
		
		
	}
	
	private double x,y,z = 0;
	
	/**
	 * 
	 * @param value a string being passed to see if its in the tree.
	 * @return returns the string "false" or "true".
	 */
	public String find(String value)
	{
		String str ="";
		String verbose = "false";
		String post = infixToPostfix();
		StringTokenizer tok = new StringTokenizer(post," ",false);
		
		while(tok.hasMoreTokens()){
			//System.out.println(tok.nextToken());
			reversedStack.push(tok.nextToken());
		}
		
		while(!reversedStack.isEmpty()){
			str = reversedStack.pop();
			if(str.equals(value)){
				verbose = "true";
			}
		}
		
		return verbose;
	}
	/**
	 * sets the x vale as the string in the value field.
	 */
	public void setX()
    {   x = Double.parseDouble(c.valueTextField.getText());
      
    }
	/**
	 * sets the y vale as the string in the value field.
	 */
    public void setY()
    {   y = Double.parseDouble(c.valueTextField.getText());
    
    }
    /**
     * sets the z vale as the string in the value field.
     */
    public void setZ()
    {   z = Double.parseDouble(c.valueTextField.getText());
        
    }
    /**
     * gets the x value
     * @return returns the x value.
     */
    public  double getX()
    { 
       return x;
    }
    /**
     * gets the y value
     * @return returns the y value.
     */
    public double getY()
    {   
        return y;
    }
    /**
     * gets the z value
     * @return returns the z value.
     */
    public double getZ()
    {   
        return z;
    }
	
	public Lab_3Model(Lab_3Control fromC)
	{
		c = fromC;
	}
	/**
	 * opens a text file
	 * @return returns the file chosen by the user.
	 */
	public File openFile()
	{
		JFileChooser chooser = new JFileChooser();
		try
		{
			FileInputStream in = null;
			chooser.setVisible(true);
			
			if(chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
			{
				File inputFile = chooser.getSelectedFile();
				in = new FileInputStream(inputFile);
				String input = in.toString();
				Scanner sc = new Scanner(inputFile);
				c.expressionTextField.setText(sc.hasNext()?sc.nextLine():"");
				
					
					while(sc.hasNext())
					{
						String nextLine = sc.nextLine();
						c.expressionTextField.setText(nextLine);
					}
					
					sc.close();
				
			}
			else
			{
				
			}
		
		}
		catch(Exception e)
		{
			
		}
		
		return chooser.getSelectedFile();
	}	
	
	/**
	 * reads the expression and checks if it has any variables.
	 * @param expression expression passed by the user in the expression textfield.
	 */
	public void readExpression(String expression)
	{
		
       c.resultArea.setText("");
        Bracketing b = new Bracketing();
        System.out.println(expression + " is "  + (b.wellBracketed(expression) ? "well" : "ill")
                + "-bracketed.");
       
		if(b.wellBracketed(expression)) 
		{
			String input = c.expressionTextField.getText();
			 c.resultArea.append("Expression: " + input+ "\n");
			if(input.contains("x") || input.contains("X"))
			{
				 c.resultArea.append("	x = "+x+ "\n");
			}
			
			if(input.contains("y") || input.contains("Y"))
			{
				 c.resultArea.append("	y = "+y+ "\n");
			}
			
			if(input.contains("z") || input.contains("Z"))
			{
				 c.resultArea.append("	z = "+z+ "\n");
			}
		}
		else 
		{
			 c.resultArea.append("Not Bracketed correctly retype expression");
		}
	}
	/**
	 * Method sets the value of the x y and z variable.
	 * @param variableName is the variable x y or z.
	 * @param value the value of the variableName thats a double.
	 */
	public void setVariable(String variableName, Double value)
	{
		if(variableName.equals("x") || variableName.equals("X"))
		{
			//x = value;
			setX();
			c.resultArea.append("x = "+x+"\n");
		}
		else if(variableName.equals("y") || variableName.equals("Y"))
		{
			//y = value;
			setY();
			c.resultArea.append("y = "+y+"\n");
		}
		else if(variableName.equals("z") || variableName.equals("Z"))
		{
			//z = value;
			setZ();
			c.resultArea.append("z = "+z+"\n");
		}
		else if(variableName.equals(null))
		{
			c.variableTextField.setText("Enter valid character");
		}
		c.variableTextField.setText("");
		c.valueTextField.setText("");
		
	}
	/**
	 * clears the Text area, variable values, number of nodes, and textfields.
	 */
	public void clear()
	{
		x = 0; y = 0; z = 0;
		c.resultArea.setText("");
		c.expressionTextField.setText("");
		c.variableTextField.setText("");
		c.valueTextField.setText("");
		numberOfNodes = 0;
	}
	/**
	 * solves the postfix expression of the string input.
	 * @param expression the string representation of the input expression.
	 */
	public void solve(String expression)
	{
		
		String result="0";
		String post = "";
		post = infixToPostfix();
		//c.resultArea.append("PostFix : "+post+ "\n");
	      result = "" + pe.evaluate(""+ post);
	      c.resultArea.append("value = " + result + "\n");
	      //c.expressionTextField.setText(result);
	}
	/**
	 * methos takes the infix expression and returns the postfix.
	 * @return returns the postfix sting representation of the expression.
	 */
	 public String infixToPostfix () {
	       theTrans  = new InToPost(c.expressionTextField.getText(),stackSize);
	       String output = theTrans.doTrans();
	      
	       return output;
	    }

	 
	  /**
	   *  method is used when user clicks infix to post button.
	   *  
	   */
	public void inToPost()
	{
		String post = infixToPostfix();
		c.resultArea.append("The postfix is " + post+"\n");
		
		//reversedStack = new LinkedStack();
		StringTokenizer tok = new StringTokenizer(post," ",false);
		
		while(tok.hasMoreTokens())
		{
			//System.out.println(tok.nextToken());
			reversedStack.push(tok.nextToken());
		}
		
		root = reversedStack.pop();
		BTPtr = new ElementBTPtr(root);
		numberOfNodes++;
		//BTPtrElementBTPtr BTPtr = new ElementBTPtr(reversedStack.pop());
		m = new BTLinked(this);
		m.insert(root);
		//m.insert(reversedStack.pop());
		//m.displayTree();
		//m.draw();
		
		while(!reversedStack.isEmpty())
		{
			String stack = reversedStack.pop();
			/*if(reversedStack.peek().equals("+") || reversedStack.peek().equals("-") || reversedStack.peek().equals("*") || reversedStack.peek().equals("/"))
			{
				//pos = "LC";
				//System.out.println("operation "+reversedStack.pop());
				m.insert(reversedStack.pop());
			}
			else
			{
				//pos = "RC";
				//System.out.println("Number "+reversedStack.pop());
				m.insert(reversedStack.pop());
			}*/
			
	
				m.insert(stack);
				numberOfNodes++;
				
		}
		
	
	}
	/**
	 *  method is used when user clicks infix to post button.
	 */
	public void draw()
	{
		/*
		reversedStack = new LinkedStack();
		StringTokenizer tok = new StringTokenizer(expression," ",false);
		while(tok.hasMoreTokens())
		{
			System.out.println(tok.nextToken());
			if(tok.nextToken().equals("("))
			{
				tok.nextToken();
			}
		}*/
		
		m.displayTree();
		m.draw();
		
	}
	/**
	 * method gets the number of nodes in the Binary Tree. 
	 * @return returns number of nodes.
	 */
	public int getNodeNumber()
	{
		return numberOfNodes;
	}
	/**
	 * method quits out of the application when the user selects the quit button.
	 */
	public void quit()
	{
		System.exit(1);
	}
	
}
