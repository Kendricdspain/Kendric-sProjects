package Lab_3;
import javax.swing.*;
import java.awt.*;

/**
 * * Class creates the components of the GUI.
 * Lab 3: CoSc 20803-055
 * @author kendricdspain
 * code altered by Kendric D'spain and written by Dr. Sanchez at TCU. 
 *
 * @author kendricdspain
 *
 */
public class Lab_3View extends JFrame
{
	JLabel expressionLabel = new JLabel("Expression:");
	JTextField expressionTextField = new JTextField(6);
	
	JLabel variableLabel = new JLabel("Variable Name:");
	JTextField variableTextField = new JTextField(6);
	
	JLabel valueLabel = new JLabel("Value:");
	JTextField valueTextField = new JTextField(6);
	
	JTextArea resultArea = new JTextArea(10,10);
	
	JButton openFileButton = new JButton("Open File");
	JButton readExpressionButton = new JButton("Read Expression");
	JButton setVariableButton = new JButton("Set Variable");
	JButton inToPostButton = new JButton("In To Post");
	JButton printTreeButton = new JButton("Print Tree");
	JButton drawTreeButton = new JButton("Draw Tree");
	JButton evaluateButton = new JButton("Evaluate");
	JButton nodeNumberButton = new JButton("Node #");
	JButton findInTreeButton = new JButton("Find in Tree");
	JButton clearButton = new JButton("Clear");
	JButton quitButton = new JButton("Quit");
	
	JPanel topPanel = new JPanel();
	JPanel bottomPanel = new JPanel();
	
	
	public Lab_3View()
	{
		this.setVisible(true);
		this.setBounds(200,400,200,400);
		this.setLayout(new BorderLayout());
		this.setTitle("Expression Evaluator");
		

		
		topPanel.setLayout(new GridLayout(3,2));
		
		resultArea.setEditable(false);
		resultArea.setText("1. Enter an expression with spaces in between each value in the expression textfield. Ex. ( 9 - 63 + 8 ( 653 * 54 ) )\n");
		resultArea.append("2. Click the Read Expression button. \n");
		resultArea.append("3. Select the Evaluate button and then select draw tree to illustrate a non balanced binary tree representation of the expression.");
		
		this.add(topPanel, BorderLayout.NORTH);
		topPanel.add(expressionLabel); topPanel.add(expressionTextField);
		topPanel.add(variableLabel); topPanel.add(variableTextField);
		topPanel.add(valueLabel); topPanel.add(valueTextField);
		
		this.add(resultArea, BorderLayout.CENTER);
		
		topPanel.setBackground(Color.lightGray);
		bottomPanel.setBackground(Color.lightGray);
		bottomPanel.setLayout(new GridLayout(3,4));
		this.add(bottomPanel, BorderLayout.SOUTH);
		bottomPanel.add(openFileButton); bottomPanel.add(readExpressionButton);
		bottomPanel.add(setVariableButton); bottomPanel.add(inToPostButton);
		bottomPanel.add(printTreeButton); bottomPanel.add(drawTreeButton);
		bottomPanel.add(evaluateButton); bottomPanel.add(nodeNumberButton);
		bottomPanel.add(findInTreeButton); bottomPanel.add(clearButton);
		bottomPanel.add(quitButton);
		
		this.pack();
	}
}
