package Lab_3;




import java.util.Scanner;

import javax.swing.JButton;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;



public interface BTModel {
	
//	public void printPath();
  //  public void loadTree();
    public void draw();
//    public void saveTree();
      public void insert(String value) ;
//    public void numberNodes() ;
//    public void addBT() ;
//    public void clear() ;
//    public void findInTree() ;
//    public void traverse(char opt) ;
 	  public void displayTree() ;
//    public void QUIT() ;
//    public void width();
//    public void minDepth();
//    public void maxDepth();
//    public void deepest();
//  
//   /// unimplemented in the fixed implementation 
//   public void reverse(); 
//   public void diameter(); 
//   public void largest(); 
//   public void copy(); 
//   public void reverseInPlace(); 
//   public void loadLevel();
//   public void insertLevel(); 
    
 }
