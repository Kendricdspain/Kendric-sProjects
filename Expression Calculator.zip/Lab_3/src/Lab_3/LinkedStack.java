/*Copyright (c) Dec 21, 2014 CareerMonk Publications and others.
 * E-Mail           	: info@careermonk.com 
 * Creation Date    	: 2015-01-10 06:15:46 
 * Last modification	: 2006-05-31 
               by		: Narasimha Karumanchi 
 * File Name			: StackWithLinkedList.java
 * Book Title			: Data Structures And Algorithms Made In Java
 * Warranty         	: This software is provided "as is" without any 
 * 							warranty; without even the implied warranty of 
 * 							merchantability or fitness for a particular purpose. 
 * 
 */


package Lab_3;

import java.util.EmptyStackException;

public class LinkedStack implements FLStack{
	private int length;  		// indicates the size of the linked list
	private ElementSPtr top; 

	//  Constructor: Creates an empty stack.
	public LinkedStack()  {
		length = 0;
		top = null;
	}
	  
	//  Adds the specified data to the top of this stack.
	public void push (String v)  {
		ElementSPtr temp = new ElementSPtr (v);
		temp.setNext(top);
		top = temp;
		length++;
	}
	  
	//  Removes the data at the top of this stack and returns a
	//  reference to it. Throws an EmptyStackException if the stack
	//  is empty.
	public String pop() throws EmptyStackException{
		if (isEmpty())
			throw new EmptyStackException();
		String result =  top.getValue();
		top = top.getNext();
		length--;
		return result;
	}	   
	  
	// Returns a reference to the data at the top of this stack.
	// The data is not removed from the stack.  Throws an
	// EmptyStackException if the stack is empty.  
	public String peek() throws EmptyStackException{
		if (isEmpty())
			throw new EmptyStackException(); 

		return top.getValue();
	}

	// Returns true if this stack is empty and false otherwise. 
	public boolean isEmpty(){
		return (length == 0);
	}
	 	  
	// Returns the number of elements in the stack.
	public int getSize(){
		return length;
	}

	
	 // Returns current number of elements in the stack.
	public int getCurrentSize(){
		return length;
	} 
	// Returns a string representation of this stack.   
	public String toString(){
		String result = "";
		ElementSPtr current = top;
		
		while (current != null){
			
			if (result.equals("")) result =  result +   current.getValue() ;
			else result =  result + "\n" + current.getValue() ;
			current = current.getNext();
		}
         result = result + "";
		return result;
	}
}
