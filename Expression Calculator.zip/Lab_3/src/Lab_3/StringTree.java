package Lab_3;



// Methods required to draw 2 Dimension depiction of a String tree
// to be ysed in conjunction with the class Display Simple Tree 
class StringTree {
  String inputString= new String();
  ElementBTPtr root;
  boolean r;
  int totalnodes = 0; //keeps track of the inorder number for horiz. scaling 
  int maxheight=0;//keeps track of the depth of the tree for vert. scaling

  StringTree() {
    root = null;
    
  }

  public int treeHeight(ElementBTPtr t){
	if(t==null) return -1;
        else return 1 + max(treeHeight(t.getLeft()),treeHeight(t.getRight()));
  }
  public int max(int a, int b){
	  if(a>b) return a; else return b;
  }

  public void computeNodePositions() {
    int depth = 1;
   // inorder_traversal(root, depth);
   inorder_traversal(root, depth);
  }

//traverses tree and computes x,y position of each node, stores it in the node

  public void inorder_traversal(ElementBTPtr t, int depth) { 
    if (t != null) {
      inorder_traversal(t.getLeft(), depth + 1); //add 1 to depth (y coordinate) 
    	  t.setXpos(totalnodes++); //x coord is node number in inorder traversal
      t.setYpos(depth); // mark y coord as depth
      inorder_traversal(t.getRight(), depth + 1);
       
    }
}

  public void reverse_traversal(ElementBTPtr t, int depth) { 
	    if (t != null) {
	     
	    	  reverse_traversal(t.getRight(), depth + 1);
	    	  t.setXpos(totalnodes++); //x coord is node number in inorder traversal
	          t.setYpos(depth); // mark y coord as depth
	    
	       reverse_traversal(t.getLeft(), depth + 1);
	    }
	}
/* below is standard Binary Search tree insert code, creates the tree */

  public ElementBTPtr insert(ElementBTPtr root, String s) { // Binary Search tree insert
    if (root == null) {
      root = new ElementBTPtr(null, s, null);
      return root;
    }
    else {
      if (s.compareTo(root.getValue()) == 0) {
         return root;  /* duplicate word  found - do nothing */
      } else  if(r) 
              { if (s.compareTo(root.getValue()) < 0)
                root.setLeft(insert(root.getLeft(), s));
                else
                root.setRight(insert(root.getRight(), s)); }

           else { if (s.compareTo(root.getValue()) < 0)
        	       root.setLeft(insert(root.getLeft(), s));
                   else
                	   root.setRight(insert(root.getRight(), s)); }
    	   if (s.compareTo(root.getValue())  < 0)
    		   root.setLeft(insert(root.getLeft(), s));
               else
            	   root.setRight(insert(root.getRight(), s));
      return root;
    }
  }
}