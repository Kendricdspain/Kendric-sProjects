package Lab_3;


import java.io.IOException;
// taken from https://www.tutorialspoint.com/javaexamples/data_intopost.htm
public class InToPost {
   private FLStack theStack;
  
   private String input;
   private String output = "";
   public InToPost(String in, int stackSize) {
      input = in;
     
       theStack = new LinkedStack();
   }
   public String doTrans() {
      for (int j = 0; j < input.length(); j++) {
         char ch = input.charAt(j);
         switch (ch) {
            case '+': 
            case '-':
               gotOper(ch, 1); 
               break; 
            case '*': 
            case '/':
               gotOper(ch, 2); 
               break; 
            case '(': 
               theStack.push(""+ch);
               break;
            case ')': 
               gotParen(ch); 
               break;
            default: 
               output = output + ch; 
               break;
         }
      }
      while (!theStack.isEmpty()) {
         output = output + " " + theStack.pop();
      }
    
      return output; 
   }
   public void gotOper(char opThis, int prec1) {
      while (!theStack.isEmpty()) {
         char opTop = theStack.pop().charAt(0);
         if (opTop == '(') {
            theStack.push(""+opTop);
            break;
         } else {
            int prec2;
            if (opTop == '+' || opTop == '-')
            prec2 = 1;
            else
            prec2 = 2;
            if (prec2 < prec1) { 
               theStack.push(""+opTop);
               break;
            } 
            else output = output + " " + opTop;
         }
      }
      theStack.push(""+opThis);
   }
   public void gotParen(char ch) { 
      while (!theStack.isEmpty()) {
         char chx = theStack.pop().charAt(0);
         if (chx == '(') 
         break; 
         else output = output  + " " + chx; 
      }
   }
   public static void main(String[] args) throws IOException {
      String input = "(4+5)*3/z";
      System.out.println("Infix is " + input + '\n');
      String output;
      InToPost theTrans = new InToPost(input, 0);
      output = theTrans.doTrans(); 
      System.out.println("Postfix is " + output + '\n');
   }
  
}
