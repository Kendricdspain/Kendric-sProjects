package Lab_3;
/* 
// Code for popping up a window that displays a custom component
// in this case we are displaying a Binary Search tree  
// reference problem 4.38 of Weiss to compute tree node x,y positions

// input is a text file name that will form the Binary Search Tree

//     java DisplaySimpleTree textfile
 modified by Antonio Sanchez  Feb 2019
 modified from www.cs.columbia.edu/~allen/S14/NOTES/DisplaySimpleTree.java
*/
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.io.*;
import java.util.*;

public class DisplaySimpleTree extends JFrame {
  JScrollPane scrollpane;
  DisplayPanel panel;
  protected Color     TCUColors   = new Color(77,25,121);

  public DisplaySimpleTree(StringTree t) {
    panel = new DisplayPanel(t);
    panel.setPreferredSize(new Dimension(800, 800));
    scrollpane = new JScrollPane(panel);
    setTitle("Binary Tree Depiction");
    getContentPane().add(scrollpane, BorderLayout.CENTER);
    getContentPane().add(new JLabel("      "), BorderLayout.EAST);
    getContentPane().add(new JLabel("      "), BorderLayout.WEST);
    getContentPane().add(new JLabel("      "), BorderLayout.NORTH);
    getContentPane().add(new JLabel("      "), BorderLayout.SOUTH);
    getContentPane().setBackground(TCUColors);
    getContentPane().add(scrollpane, BorderLayout.CENTER);
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    pack();  // cleans up the window panel
  }

  class DisplayPanel extends JPanel {
     StringTree t;
     int xs;
     int ys;

    public DisplayPanel(StringTree t) {
      this.t = t; // allows display routines to access the tree
      setBackground(new Color(230,230,150));
      setForeground(TCUColors);
    }

    protected void paintComponent(Graphics g) {
      g.setColor(getBackground()); //colors the window
      g.fillRect(0, 0, getWidth(), getHeight());
      g.setColor(getForeground()); //set color and fonts
      Font MyFont = new Font("SansSerif",Font.BOLD,20);
      Font fontLine = new Font("SansSerif",Font.BOLD,20);
      g.setFont(MyFont);
      xs=150;   //where to start printing on the panel
      ys=80;
      g.drawString("         Two Dimensional Depiction",xs,ys);
      ys=ys+10;
      int start=0;
      MyFont = new Font("SansSerif",Font.BOLD,20); //bigger font for tree
      g.setFont(MyFont);
      g.setColor(Color.RED);
      this.drawTree(g, t.root); // draw the tree
      revalidate(); //update the component panel
    }

      public void drawTree(Graphics g, ElementBTPtr root) {//actually draws the tree
      int dx, dy, dx2, dy2;
      int SCREEN_WIDTH=750; //screen size for panel
      int SCREEN_HEIGHT=650;
      int XSCALE, YSCALE;  
      XSCALE=SCREEN_WIDTH/t.totalnodes; //scale x by total nodes in tree
      YSCALE=(SCREEN_HEIGHT-ys)/(t.maxheight+1); //scale y by tree height

      if (root != null) { // inorder traversal to draw each node
        drawTree(g, root.getLeft()); // do left side of inorder traversal 
        dx = root.getXpos() * XSCALE; // get x,y coords., and scale them 
        dy = root.getYpos() * YSCALE +ys;
        String s =  root.getValue(); //get the word at this node
        
        g.setColor(Color.RED);
        Graphics2D g2 = (Graphics2D) g; 
        g2.setStroke(new BasicStroke(3));
// this draws the lines from a node to its children, if any
        if(root.getLeft()!=null){ //draws the line to left child if it exists
          dx2 = root.getLeft().getXpos() * XSCALE; 
          dy2 = root.getLeft().getYpos() * YSCALE +ys;
          g2.drawLine(dx,dy,dx2,dy2);
          }
        if(root.getRight()!=null){ //draws the line to right child if it exists
          dx2 = root.getRight().getXpos() * XSCALE;//get right child x,y scaled position
          dy2 = root.getRight().getYpos() * YSCALE + ys;
          g2.drawLine(dx,dy,dx2,dy2);
          }
        drawTree(g, root.getRight()); //now do right side of inorder traversal 
        g.setFont(new Font("SansSerif",Font.BOLD,26));
        g.setColor(new Color (52,32,123));
        
        g.setColor(Color.CYAN);
        g.fillOval( dx,dy, 15, 15 );
        g.setColor(new Color (52,32,123));
        g.drawString(s, dx-3, dy-3); // draws the word
        repaint();
      }
      }
  }
}

  



