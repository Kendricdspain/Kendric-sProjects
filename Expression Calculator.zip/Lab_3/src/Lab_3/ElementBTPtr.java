package Lab_3;


public class ElementBTPtr
{   private ElementBTPtr left,right;
    private String value;
    // to be used in balanced trees
    private int height;
    //stores x and y position of the node in the tree
    // to be use in the 2D Depiction
    private int xpos;
    private int ypos;
    
	public ElementBTPtr() 
	       { value = null; left = right = null; }
	
    public ElementBTPtr(String v) 
    {  left = right = null; value = v; }
    
    public ElementBTPtr( ElementBTPtr l, String v, ElementBTPtr r) 
    {  left = l; value = v; right = r; }
    
     public void setValue(String v)		
	{   value =  v; }
     
	public String getValue()		
	{ return value; }
	
	// Returns the node the left child 
	public ElementBTPtr getLeft(){ return left; }
	
    // Sets the left child.
    public void setLeft (ElementBTPtr l){ left = l; }
    
    // Returns the node the right child 
 	public ElementBTPtr getRight(){ return right; }
 	
     // Sets the right child.
     public void setRight (ElementBTPtr r){ right = r; }
     
	// Tests whether this node is a leaf node.
	public boolean isLeaf() {
		return left == null && right == null;
	}
	public int getXpos(){ return xpos; }
	
    // Sets the right child.
    public void setXpos (int r){ xpos = r; }
    
	// Tests whether this node is a leaf node.
    public int getYpos(){ return ypos; }
    
    // Sets the right child.
    public void setYpos (int r){ ypos = r; }
    
	// Tests whether this node is a leaf node.
    public void setHeight(int h)		
	{   height = h; }
    
    /**
     * gets the height of the node.
     * @return returns the height.
     */
public int getHeight()		
	{ return height; }
	
}
				
				
		

