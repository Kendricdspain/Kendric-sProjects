/* Author  Antonio Sanchez.
 *  
 * Last modification	: Feb 2019         
 * Wrapper class for  ElementBTPtr whihc is root of a tree
   based on an extension to the code of Narasimha Karumanchi 
 *     in  Structures And Algorithms Made In Java
 
 */


package Lab_3;



import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JTextArea;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;



public class BTMethods {
	
    private ElementBTPtr t;
    private final boolean verbose = true;
    public BTMethods(ElementBTPtr bt) {t = bt;}
    public Lab_3Model m = new Lab_3Model();
    
    ElementBTPtr temp = new ElementBTPtr();
    ElementBTPtr rootAddress = new ElementBTPtr();
   
   
    	public ElementBTPtr deleteBT() {return new ElementBTPtr();}
    
    public ElementBTPtr loadTree(String file)
    {  String word="";
       ElementBTPtr root=null;
       System.out.println("File is " + file);
    	 try {
          	BufferedReader input =
                new BufferedReader(
                  new InputStreamReader(
                      new FileInputStream(file)));
         
    // Insert the text contained in input after the last line of this text, and
    // select the last line inserted.
            while(true) {
              String line = input.readLine();
              if (line == null)  break;
              Scanner dataLine=new Scanner(line);
              while (dataLine.hasNext()) { 
                  word=dataLine.next(); 
                  root = insert(root, word);
               }
             }
        input.close();
        
    }
    catch (IOException e) { System.out.println(e.getMessage()); }
    return root;
    }
    

    public void saveTree (ElementBTPtr root, String s)
    { try {
    	      BufferedWriter output =
                new BufferedWriter(
                    new OutputStreamWriter(
                        new FileOutputStream(s)));
     // Write this text to output.
         String line = saveItems(root);
          output.write(line );
         output.close();
         }
    catch (IOException e) { System.out.println(e.getMessage()); }
    }
    
    // Tests whether the root argument contains within itself the data argument.
 	public boolean findInBT(ElementBTPtr root, String v) {
 		if (root == null)
 		    return false;
 		if (root.getValue().equals(v))
 		    return true;
 		return findInBT(root.getLeft(), v)  || findInBT(root.getRight(), v);
 	}
  
 	public void printPaths(ElementBTPtr  root, JTextArea ta) {
		  String[] path = new String[256];
		  printPaths(root, path, 0, ta);
	}
	private void printPaths(ElementBTPtr  root, String[] path, int pathLen, JTextArea ta) {
		if (root == null) return;
		// append this node to the path array
		path[pathLen] = root.getValue();
		pathLen++;
		// it's a leaf, so print the path that led to here
		if (root.getLeft() == null && root.getRight() == null) {
			printArray(path, pathLen, ta);
		}
		else {	// otherwise try both subtrees
			printPaths(root.getLeft(), path, pathLen, ta);
			printPaths(root.getRight(), path, pathLen, ta);
		}
	}
	private void printArray(String[] ints, int len, JTextArea ta) {
		//ta.append(len + " paths found");
		for (int i=0; i<len; i++) {
			System.out.print(ints[i] + " ");
			ta.append(  "=> " + ints[i]);
		}
		System.out.println();
		ta.append("\n" );
	}
 	
	
	
	// Returns a String representation of this .
			public String display(ElementBTPtr root, char opt) {
				
				if (root.isLeaf()) { System.out.println( " display "+ root.getValue() );
				   return root.getValue();
				}
				else {  System.out.println( " display tree "+ root.getValue() );
					    String rootV, leftV = "null", rightV = "null";
					    rootV = root.getValue();
					    if (root.getLeft() != null) {
							leftV = display(root.getLeft(), opt); 
					    }
					    if (root.getRight() != null) {
							rightV = display(root.getRight(),opt);
					    }
					    switch (opt)
					    { case 'p' : return rootV + " (" + leftV + ",  " + rightV + ") ";
					      case 'i' : return " (" + leftV + "), " + rootV +  " ( " + rightV + ") "+ "";  //infix return 
					      case 'r' : return  " (" + leftV + ", " + rightV + ") " + rootV+ "" ;  //postfix or reverse return 
					    }
				}
			return "";
			}
		
	// Returns a String representation of this  for save tree display.
	public String saveItems(ElementBTPtr root) {
	String sR = "";
	if (root.isLeaf()) {return root.getValue();}
	else { String rootV, leftV = "null", rightV = "null";
			rootV = root.getValue();
			if (root.getLeft() != null) leftV = saveItems(root.getLeft()); 
			if (root.getRight() != null) rightV = saveItems(root.getRight());
			if(!(rootV.equals("null"))) sR = rootV + "\n"; 
			if(!(leftV.equals("null"))) sR += leftV + "\n"; 
			if(!(rightV.equals("null"))) sR += rightV + "\n"; 
			}
	return sR;
	}				
											
	/* below is standard Binary Search tree insert code, creates the tree */
  public ElementBTPtr insert(ElementBTPtr root, String v) { // Binary Search tree insert
	  		
	
	  		
			if (root == null) { 
				
				//if(m.numberOfNodes == 0) { temp = new ElementBTPtr(v); }
				
				
				root = new ElementBTPtr(v);// only if list is empty
				
				/*if(temp == null)
				{
					temp = root;
				}*/
				
				m.numberOfNodes++;
						        return root;
			}
			
			else {
					
				
				if(v.equals("+") || v.equals("-") || v.equals("*") || v.equals("/")){
					root.setLeft( insert(root.getLeft(), v));
					temp.setLeft( insert(root.getLeft(), v));
					
					root = root.getLeft();
				
					
			
				}
				else {
					root.setRight( insert(root.getRight(), v));
					
					//temp.setRight( insert(root.getRight(), v));
					
				}
				return root;
			
				
			}
			
			/*else {  if (v.compareTo(root.getValue()) == 0) return root;   duplicate word  found - do nothing 
				    else   if (v.compareTo(root.getValue()) < 0) root.setLeft( insert(root.getLeft(), v));
						   else root.setRight( insert(root.getRight(), v)) ; //
					return root;
				  }*/
		}
						
						
	
			
	
	public void postFix(ElementBTPtr root){
		if(root != null) {
			postFix(root.getLeft());
			postFix(root.getRight());
			System.out.println(root.getValue());
		}
	}
	public void preFix(ElementBTPtr root){
		if(root != null) {
			System.out.println(root.getValue());		
			preFix(root.getLeft());
			preFix(root.getRight());
		}
	}
	
	public void inFix(ElementBTPtr root){
		if(root != null) {
			inFix(root.getLeft());
			System.out.println(root.getValue());		
			inFix(root.getRight());
		}
	}
	public String addBT(ElementBTPtr  root) {
		if(root == null) return "null";
		else return(root.getValue() +","+ addBT(root.getLeft()) +","+  addBT(root.getRight()));
	}
    	
		
		// Returns the total number of nodes in this binary tree (include the root in the count).
				public int numberOfNodes(ElementBTPtr root) {
					int leftCount = root.getLeft() == null ? 0 : numberOfNodes(root.getLeft());
					int rightCount = root.getRight() == null ? 0 : numberOfNodes(root.getRight());
					return 1 + leftCount + rightCount;
				}

		// Returns a new ElementBTPtr equal to (but not the same as) this binary tree.
				// Every node in this new BinaryTreeNode will be created by the copy method; values
				// will be identical (==) to values in the given binary tree.
				public ElementBTPtr copy(ElementBTPtr root) {
					ElementBTPtr left =  null, right = null;
					if (root.getLeft() != null) {
						left = copy(root.getLeft());
					}
					if (root.getRight() != null) {
						right = copy(root.getRight());
					}
					return new ElementBTPtr( left, root.getValue(), right);
				}
				
				// Returns a new ElementBTPtr which is the mirror image of the binary tree whose
				// root is at this binary tree. That is, for every node in the new binary tree,
				// its children are in reverse order (left child becomes right child, right
				// child becomes left child).
				public ElementBTPtr reverse(ElementBTPtr root) {
					ElementBTPtr left =  null, right = null;
					if (root.getLeft() != null) {
						left = reverse(root.getLeft());
					}
					if (root.getRight()  != null) {
						right = reverse(root.getRight());
					}
					System.out.println( " reverse "+ root.getValue() );
					return new ElementBTPtr( right, root.getValue(), left);
				}

				// Rearranges the binary tree rooted at this binary tree to be the mirror image
				// of its original structure. No new ElementBTPtr nodes are created in this
				// process.
				public ElementBTPtr reverseInPlace(ElementBTPtr root) {
					if (root.getLeft() != null) {
						reverseInPlace(root.getLeft());
					}
					if (root.getRight() != null) {
						reverseInPlace(root.getRight());
					}
					ElementBTPtr temp = root.getLeft();
					root.setLeft(root.getRight());
					root.setRight(temp);
					return root;
				}       

public int width(ElementBTPtr root)
				   {
				      int max = 0;
				      int height = maxDepthRecursive(root);
				      for(int k = 0; k <= height; k++)
				      {
				         int tmp = width(root, k);
				         if(tmp > max) max = tmp;
				      }
				      return max;
				   }
				   // Returns the number of node on a given level
 public int width(ElementBTPtr root, int depth)
		 { if(root==null) 
				 return 0;
			  else
			if(depth == 0) 
				 return 1;
		    else  return width(root.getLeft(), depth-1) + width(root.getRight(), depth-1);
		  }
 public int maxDepthRecursive(ElementBTPtr root) {
		 if(root == null) return 0;
		  /* compute the depth of each subtree */
			int leftDepth = maxDepthRecursive(root.getLeft());
			int rightDepth = maxDepthRecursive(root.getRight());
				        return (leftDepth > rightDepth) ? leftDepth + 1 : rightDepth + 1;
	} 
		public static boolean printAllAncestors(ElementBTPtr root, ElementBTPtr descendant){
			if(root == null) 
				return false;
			if(root.getLeft() == descendant || root.getRight() == descendant || 
				printAllAncestors(root.getLeft(), descendant) ||
				printAllAncestors(root.getRight(), descendant)) 
			    {
				System.out.println(" this value is an ancestor " + root.getValue());
				return true;
			    }
			return false;
		}
        
		/*public int minDepth(ElementBTPtr root) {
	        if(root == null) return 0;
	        LinkedQueueBT qBT =  new LinkedQueueBT();
	        qBT.enQueue(root);
	        qBT.enQueue(null);
	        int count = 1;
	        while(!qBT.isEmpty()){
	            ElementBTPtr currentNode = qBT.deQueue();
	            if(currentNode != null){
	                if(currentNode.getLeft() == null && currentNode.getRight() == null){
	                    return count;
	                }
	                if(currentNode.getLeft() != null){
	                    qBT.enQueue(currentNode.getLeft());
	                }
	                if(currentNode.getRight() != null){
	                    qBT.enQueue(currentNode.getRight());
	                }   
	            }else{
	                if(!qBT.isEmpty()){
	                    count++;
	                    qBT.enQueue(null);
	                }
	            }
	        }
	        return count;
	    } */
   
     

 
}
