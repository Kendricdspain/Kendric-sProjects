package Lab_3;


import java.util.Scanner;

/**
 * Represents an integer evaluator of postfix expressions. Assumes 
 * the operands are constants.
 *
 * @author Lewis and Chase
 * @version 4.0
 * * modified by Antonio Sanchez to run using the ADT defined in class
 */
public class PostfixEvaluator
{    
    private FLStack stack;
    private final static char ADD = '+';
    private final static char SUBTRACT = '-';
    private final static char MULTIPLY = '*';
    private final static char DIVIDE = '/';
    /**
     * Reads and evaluates multiple postfix expressions.
     */
   public PostfixEvaluator() {
	   
   }
    
    public static void main(String[] args)
    {
        String expression, again;
        double result;
        
        Scanner in = new Scanner(System.in);
      
        do
        {  
            PostfixEvaluator evaluator = new PostfixEvaluator(50);
			System.out.println("Enter a valid post-fix expression one token " +
							   "at a time with a space between each token (e.g. 5 4 + 3 2 1 - + *)");
			System.out.println("Each token must be an integer or an operator (+,-,*,/)");
            expression = in.nextLine();

            result = evaluator.evaluate(expression);
            System.out.println();
            System.out.println("That expression equals " + result);

            System.out.print("Evaluate another expression [Y/N]? ");
         again = in.nextLine();
            System.out.println();
        }
        while (again.equalsIgnoreCase("y"));
   }
    
  
    /**
     * Sets up this evaluator by creating a new stack.
     */
    public PostfixEvaluator(int n)
    {  stack = new LinkedStack(); }
    private Lab_3Model c = null;
    public PostfixEvaluator( Lab_3Model fromC)
    {    c = fromC;
         stack = new LinkedStack();
        
    }

    
    
    
    /**
     * Evaluates the specified postfix expression. If an operand is
     * encountered, it is pushed onto the stack. If an operator is
     * encountered, two operands are popped, the operation is
     * evaluated, and the result is pushed onto the stack.
     * @param expr string representation of a postfix expression
     * @return value of the given expression
     */
    public double evaluate(String expr)
    {  // stack = new LinkedStack();
    //	Lab_3Model m = new Lab_3Model();
    
    	String op1S, op2S;
        double op1, op2, result = 0, value =0;
        String token;
        Scanner parser = new Scanner(expr);
        System.out.println(" exp is " + expr);
        while (parser.hasNext())
        {
            token = parser.next();
            System.out.println(" next is "+ token);
            if (isOperator(token))
            {
            	   op1S = stack.pop();
            	   op2S = stack.pop();
            	   System.out.println( op2S  );
            	   System.out.println( op1S  );
            	   if(op1S.equals("x"))  op1S = ""+ c.getX();
            	   if(op1S.equals("y"))  op1S = ""+ c.getY();
            	   if(op1S.equals("z"))  op1S = ""+ c.getZ();
            	   if(op2S.equals("x"))  op2S = ""+ c.getX();
            	   if(op2S.equals("y"))  op2S = ""+ c.getY();
            	   if(op2S.equals("z"))  op2S = ""+ c.getZ();
            	  
                op2 = Double.parseDouble(op1S);
                op1 = Double.parseDouble(op2S);
                result = evaluateSingleOperator(token.charAt(0), op1, op2);
                stack.push(""+result);
            }
            else
                stack.push(token);
        }

        return result;
    }

    /**
     * Determines if the specified token is an operator.
     * @param token the token to be evaluated 
     * @return true if token is operator
     */
    private boolean isOperator(String token)
    {   System.out.println( "operator "+ token);
        return ( token.equals("+") || token.equals("-") ||
                 token.equals("*") || token.equals("/") );
    }

    /**
     * Peforms integer evaluation on a single expression consisting of 
     * the specified operator and operands.
     * @param operation operation to be performed
     * @param op1 the first operand
     * @param op2 the second operand
     * @return value of the expression
     */
    private double evaluateSingleOperator(char operation, double op1, double op2)
    {
        double result = 0;

        switch (operation)
        {
            case ADD:
                result = op1 + op2;
                break;
            case SUBTRACT:
                result = op1 - op2;
                break;
            case MULTIPLY:
                result = op1 * op2;
                break;
            case DIVIDE:
                result = op1 / op2;
        }

        return result;
    }
}
