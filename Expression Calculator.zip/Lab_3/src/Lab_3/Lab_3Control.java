package Lab_3;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.awt.*;

/**
 * Class instantiates the control constructor and listens to buttons and calls methods in the model when the appropriate buttons are selected.
 * Lab 3: CoSc 20803-055
 * @author kendricdspain
 * code altered by Kendric D'spain and written by Dr. Sanchez at TCU. 
 *
 */
public class Lab_3Control extends Lab_3View implements ActionListener
{
	Lab_3Model m = new Lab_3Model(this);
	
	public Lab_3Control()
	{
		openFileButton.addActionListener(this);
		readExpressionButton.addActionListener(this);
		setVariableButton.addActionListener(this);
		inToPostButton.addActionListener(this);
		printTreeButton.addActionListener(this);
		drawTreeButton.addActionListener(this);
		evaluateButton.addActionListener(this);
		nodeNumberButton.addActionListener(this);
		findInTreeButton.addActionListener(this);
		clearButton.addActionListener(this);
		quitButton.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource() == openFileButton){
			m.openFile();
		}
		else if(e.getSource() == readExpressionButton){
			m.readExpression(expressionTextField.getText());
		}
		else if(e.getSource() == setVariableButton){
			if(valueTextField.getText().equals("")){
			valueTextField.setText("Enter valid value");}
			
			else
			{
				{m.setVariable(variableTextField.getText(),Double.parseDouble(valueTextField.getText()));}
			}
		}
		else if(e.getSource() == inToPostButton){
			m.inToPost();
		}
		else if(e.getSource() == printTreeButton){
			
		}
		else if(e.getSource() == drawTreeButton){
			m.inToPost();
			m.draw();
		}
		else if(e.getSource() == evaluateButton){
			m.solve((expressionTextField.getText()));
		}
		else if(e.getSource() == nodeNumberButton){
			variableTextField.setText(Integer.toString(m.getNodeNumber()));
		}
		else if(e.getSource() == findInTreeButton){
			valueTextField.setText(m.find(valueTextField.getText()));
		}
		else if(e.getSource() == clearButton){
			m.clear();
		}
		else if(e.getSource() == quitButton){
			m.quit();
		}
		
	}
	
	public static void main( String [] args)
	{
		new Lab_3Control();
	}
	
}
