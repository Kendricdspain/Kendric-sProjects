package Lab5;



import java.io.*;
import java.net.*;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.*;

import Lab5.ChatServer.ClientHandler;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import sun.audio.*;
import java.applet.AudioClip;


/**
 * Program: Lab 5 by Kendric D'spain
 * 
 * Info: Name of the client is set as the Port number of that client. If the To: textfield is set to All then it 
 * will send to all clients and if it is set to the specific port number of another client it will send it to that client only
 * and will not show the message for the sender but only to the recipient.
 * 
 *  Assumes port 5000 for the connections
 */

public class SimpleChatClient implements WindowListener
{   
	public final boolean verbose = true;
    JCheckBox encBox;
    BufferedReader reader;
    PrintWriter writer;
    Socket sock;
    
    JTextField toTextField,toTextfield,outgoing, clientText;
    String todayS, timeS, minS, secS, str,message;
    Hashtable<Integer, Integer> hash;
    Calendar now; int year,month,day,hour,min,sec,i,port;
	public Object clientName;
	JTextArea consoleClient,incoming;
    public static void main(String args[]) 
    {
	    System.out.println("Chat Service");
	    SimpleChatClient client =  new SimpleChatClient();
		client.go();
	}
    /**
     * method creates the view of the client.
     * 
     */
    public void go() {
        JFrame frame = new JFrame(" Chat ");
        JLabel nameLabel = new JLabel("Name");
        clientText = new JTextField(5);
        
        JLabel toLabel = new JLabel("To");
        toTextField = new JTextField(5);
        
        consoleClient = new JTextArea(5,50);
        
        
        encBox = new JCheckBox("Encrypt");
        int sec = Integer.parseInt(processTime(3));
        if( sec > 50 ) frame.setBackground(Color.blue);
             else if( sec > 40 ) frame.setBackground(Color.magenta);
               else if( sec > 30 ) frame.setBackground(Color.yellow);
                 else if( sec > 20 ) frame.setBackground(Color.red);
                   else if( sec > 10 ) frame.setBackground(Color.black);
                                    else frame.setBackground(Color.green);
        frame.setBounds(400+5*sec,8*sec,300,300);
        JPanel mainPanel = new JPanel();
        incoming = new JTextArea(15, 50);
        
        consoleClient.setForeground(Color.YELLOW);
        consoleClient.setBackground(Color.BLACK);

        
        consoleClient.setLineWrap(true);
        incoming.setLineWrap(true);
        
        consoleClient.setWrapStyleWord(true);
        incoming.setWrapStyleWord(true);
        clientText.setEditable(false);
        consoleClient.setEditable(false);
        incoming.setEditable(false);
        incoming.setText("Client logged on "+processTime(2) +"\n");
        consoleClient.setText("Client logged on "+processTime(2) +"\n");
        
        JScrollPane qScroller = new JScrollPane(incoming);
        JScrollPane wScroller = new JScrollPane(consoleClient);
        qScroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        qScroller.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        wScroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        wScroller.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        outgoing = new JTextField(20);
        JButton sendButton = new JButton("Send");
        
        sendButton.addActionListener(new SendButtonListener());
        mainPanel.add(qScroller);
        mainPanel.add(nameLabel);
        mainPanel.add(clientText);
        mainPanel.add(toLabel);
        mainPanel.add(toTextField);
        toTextField.setText("All");
        mainPanel.add(outgoing);
        mainPanel.add(sendButton);
        mainPanel.add(encBox);
        mainPanel.add(wScroller);
        frame.getContentPane().add(BorderLayout.CENTER, mainPanel);
        setUpNetworking();
       
        Thread readerThread = new Thread(new IncomingReader());  // thread to read messages
        readerThread.start();
        frame.addWindowListener(this);
        frame.setSize(650, 500);
        frame.setVisible(true);
        
    }
    /**
     * method gets the current time.
     * @param option is the day, time and secs.
     * @return returns null
     */
    
    public String processTime(int option)
	   {    
	    	 now = Calendar.getInstance();
		     year = now.get(Calendar.YEAR); 
	         month = now.get(Calendar.MONTH)+1; 
			 day = now.get(Calendar.DAY_OF_MONTH);
			 hour = now.get(Calendar.HOUR);
			 min =  now.get(Calendar.MINUTE);	  
			 sec =  now.get(Calendar.SECOND);
			 
			 if (min < 10 )  minS =  "0" + min ;  else  minS = "" + min;
			 
			 if (sec < 10 )  secS =  "0" + sec ;  else  secS = "" + sec;
			 todayS =  month + " / " + day + " / " + year;  
			 timeS  = hour + " : " + minS + " : " + secS; 
			 switch(option) {
			 case (0):  return todayS  ; 
			 case (1):  return timeS;
			 case (2):  return todayS + " @ " + timeS ; 
			 case (3): return secS;
        } 
        return null;  // should not get here
     }
    
    private void setUpNetworking() {
        try {if (verbose) System.out.println("Opening socket at port 5000");
            sock = new Socket("127.0.0.1", 5001);
            InputStreamReader streamReader = new InputStreamReader(sock.getInputStream());
            reader = new BufferedReader(streamReader);
            writer = new PrintWriter(sock.getOutputStream());
            System.out.println("networking protocol established");
            System.out.println("Local Port: "+sock.getLocalPort());
            
            
            
            hash = new Hashtable<Integer, Integer>();
            port = sock.getLocalPort();
            i++;
            hash.put(i, port);
            
            str = Integer.toString(hash.get(i));
            
           
            clientText.setText(str);
            
        }
        catch(IOException ex)
        {
            ex.printStackTrace();
        }
    }
    
    
    
    public class SendButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent ev) {
            try 
            {
            	
            	
            	if(encBox.isSelected())
            	{
            		// Trying to send whole line of text to server.
            	
            		message =  ProEncDec(true,outgoing.getText());
            		message = "Name "+ str +" To "+ toTextField.getText()+ " Encrypt TRUE " + "MESSAGE _"+ message+"_ "+processTime(2);
            		Boolean state = false;
            		encBox.setSelected(state);
            		
            		if (verbose) System.out.println("Sending coded message => " + message);
                    writer.println(message);
                    writer.flush();
                    
                    File soundFile = new File("EmailSentSound.wav");
                    AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFile);              
                   Clip clip = AudioSystem.getClip();
                   clip.open(audioIn);
                   clip.start();
                    
            	}
            	else
            	{
            		message = "Name "+ str +" To "+ toTextField.getText()+ " Encrypt FALSE " + "MESSAGE _"+ outgoing.getText()+"_ "+processTime(2);
            		
            		if (verbose) System.out.println("Sending coded message => "+ message);
                    writer.println(message);
                    writer.flush();
                  
                    File soundFile = new File("EmailSentSound.wav");
                    AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFile);              
                   Clip clip = AudioSystem.getClip();
                   clip.open(audioIn);
                   clip.start();
            	}
            	 
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
            outgoing.setText("");
            outgoing.requestFocus();
        }
    }
    /**
    Encrypts a command.
    @param option is true or false
    @param str String to encrypt/decrypt
    @return String to encrypted/decrypted
 */   
    
    public String ProEncDec(boolean option, String str)
    {   String x= "";
        byte[] incoming = str.getBytes();
        byte[] outgoing = new byte[incoming.length];
        for (int i=0; i < incoming.length; i++)
   	     if(option)   outgoing[i] = (byte)(incoming[i]+3); 
   	     else  outgoing[i] = (byte)(incoming[i]-3); 
   	    x =  new String(outgoing);
   	    return x;
    }  
       
    /** Internal class to handle the IncomingReader Handler
    The benefit of using an internal class is that we have access to the various objects of the 
    external class
    
    */
    
    class IncomingReader implements Runnable {
    	/**
         * Method RUN to be executed when thread.start() is executed
         */
    	
        public void run() 
        {
        	SimpleChatClient chatclient = new SimpleChatClient();
            String message;
            try {
                while ((message = reader.readLine()) != null) 
                {
                	 if (verbose) System.out.println("Encoded received =>  " + message);
                	 message  = ProEncDec(false, message);
                	 
                	
                	StringTokenizer tokUSER = new StringTokenizer(message," ", false);
                	String Name = tokUSER.nextToken();
                	System.out.println(Name);
                	String Port = tokUSER.nextToken();
                	System.out.println(Port);
                	tokUSER.nextToken();
                	String To = tokUSER.nextToken();
                	System.out.println(To);
                	
                	if(To.equals("All") || (To.equals("ALL")))
                	{
                		consoleClient.append(message + "\n");
                		
                		StringTokenizer tok2 = new StringTokenizer(message, "_", false);
                    	tok2.nextToken();
                    	String mess = tok2.nextToken();
                    	
                    	
                    	incoming.append(Port + ": " +mess+ "\n");
                	}
                	else
                	{
                		if(clientText.getText().equals(To))
                		{
                			consoleClient.append(message + "\n");
                			
                			StringTokenizer tok2 = new StringTokenizer(message, "_", false);
                        	tok2.nextToken();
                        	String mess = tok2.nextToken();
                        	
                        	
                        	incoming.append(Port + ": " +mess+ "\n");
                		}
                	}
                }
            } catch (IOException ex)
            {
                ex.printStackTrace();
            }
        }
    }
	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowClosing(WindowEvent e) {
		System.exit(1);
		
	}
	@Override
	public void windowClosed(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}
}

