package Lab5;

/**
 * 
 * 
 *  This program was taken as an example presented in
 *  Head First JAVA 2 ed  K Sierra and Bert Bates
 *  Some added modifications were done to allow its readability
 *  
 *  Assumes port 5000 for the connections
 */



import java.io.*;
import java.net.*;
import java.util.*;

import Lab5.ChatServer.ClientHandler;

import java.awt.*;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;


/**
 * Class creates the server for the clients to communicate through.
 * @author kendricdspain
 *
 */
public class ChatServer extends Frame  implements WindowListener
{
    ArrayList<PrintWriter> clientOutputStreams;
    BufferedReader reader;
    Socket sock;
    int port;
    int i = 0;
    public final boolean verbose = true;
    boolean flag = true;
    public  TextArea  result = new TextArea(40,40);
    
    Label timeLabel = new Label("Date and Time ", Label.RIGHT);
    TextField timeField = new TextField("");
    Panel  displayTime = new Panel(new GridLayout(1,2));
    int year,month,day,hour,min,sec;
    String todayS, timeS, minS, secS;
    Calendar now;
    public static void main(String args[]) {
		System.out.println("Chat Service");
	    
	    ChatServer server = new ChatServer();
	    server.go();
	    
     	
	} 
    /** Constructor
     * 
     */
        public ChatServer()
	  {    setLayout(new BorderLayout());
		   setSize(600, 800);
		   displayTime.add(timeLabel);displayTime.add(timeField);
		   add(displayTime,BorderLayout.NORTH);
		   add(result,BorderLayout.CENTER);
		setBackground(Color.RED);
		result.setBackground(Color.BLACK);
		result.setForeground(Color.YELLOW);

		addWindowListener(this);
    	setVisible(true);
	}
        
    public String processTime(int option)
	   {    now = Calendar.getInstance();
	        year = now.get(Calendar.YEAR); 
            month = now.get(Calendar.MONTH)+1; 
            day = now.get(Calendar.DAY_OF_MONTH);
            hour = now.get(Calendar.HOUR);
            min =  now.get(Calendar.MINUTE);	  
            sec =  now.get(Calendar.SECOND);
            if (min < 10 )  minS =  "0" + min ;  else  minS = "" + min;
            if (sec < 10 )  secS =  "0" + sec ;  else  secS = "" + sec;
            todayS =  month + " / " + day + " / " + year;  
            timeS  = hour + " : " + minS + " : " + secS; 
            switch(option) {
            case (0):  return todayS  ; 
            case (1):  return timeS;
            case (2):  return todayS + " @ " + timeS ; 
           } 
           return null;  // should not get here
        }
     
    /**
     * method Starts server and starts a new thread.
     */
    public void go() {
        clientOutputStreams = new ArrayList<PrintWriter>();
        try {
            ServerSocket serverSock = new ServerSocket(5001);
             if (verbose) System.out.println(" Server IP 127.0.0.1. ready at port 5000 " );
                if (verbose) System.out.println(" ___________________"
                    +"________________________________________________"  ); 
            result.append("Server started on " + processTime(2)+"\n");
            if (verbose) { System.out.println ("\nStart Server on " + processTime(2)); 
             timeField.setText(processTime(2));
             }   
            while(true) {
            	
                Socket clientSocket = serverSock.accept();
                PrintWriter writer = new PrintWriter(clientSocket.getOutputStream());
                clientOutputStreams.add(writer);  
                Thread t = new Thread(new ClientHandler(clientSocket));
                t.start();  // to execute the run() method of ClientHandler
                if(verbose) System.out.println("got a connection");
               
                
            }
        } catch (Exception ex) { ex.printStackTrace(); }
    }
    
    public void tellEveryone(String message) 
    {
        Iterator<PrintWriter> it = clientOutputStreams.iterator();
      //  result.append(message  + " broadcasted on " + processTime(2)+ "\n");
        message = ProEncDec(true, message);
        while (it.hasNext()) {
            try {
                PrintWriter writer = (PrintWriter) it.next();
                System.out.println("coded message" + message);
                writer.println(message);
                writer.flush();
            } catch (Exception ex) { ex.printStackTrace(); }
        }
    }
    
    public void tellUser(String message)
    {
    	Iterator<PrintWriter> it = clientOutputStreams.iterator();
       // result.append(message  + " broadcasted on " + processTime(2)+ "\n");
        message = ProEncDec(true, message);
        while (it.hasNext()) {
            try {
                PrintWriter writer = (PrintWriter) it.next();
                System.out.println("coded message" + message);
                writer.println(message);
                writer.flush();
            } catch (Exception ex) { ex.printStackTrace(); }
        }
    }
    
    /**
    Encrypts a command.
    @param option is a boolean value true or false
    @param str String to encrypt/decrypt
    @return String to encrypted/decrypted
 */   
    
    public String ProEncDec(boolean option, String str)
    {   String x= "";
        byte[] incoming = str.getBytes();
        byte[] outgoing = new byte[incoming.length];
        for (int i=0; i < incoming.length; i++)
   	     if(option)   outgoing[i] = (byte)(incoming[i]+3); 
   	     else  outgoing[i] = (byte)(incoming[i]-3); 
   	    x =  new String(outgoing);
   	    return x;
    }  
    
    /** Internal class to handle the Client Handler
    The benefit of using an internal class is that we have access to the various objects of the 
    external class
    
    */
     public class ClientHandler  implements Runnable { 
    	 
      /**
       * Constructor of the inner class
       * @param clientSocket is the socket of the client
       */
    	 
    	 
       public ClientHandler(Socket clientSocket) {
            try {
                sock = clientSocket;
                InputStreamReader isReader = new InputStreamReader(sock.getInputStream());
                reader = new BufferedReader(isReader);
                if (verbose) System.out.println("new client " );
                if (verbose) System.out.println(" new client at address "
                  +  sock.getLocalAddress() + " at port " +  sock.getLocalPort()); 
                
               
                if (verbose) System.out.println(" Client at address " +  sock.getInetAddress() + " at port " +  sock.getPort()  );
               
                
                if (verbose) System.out.println(" ___________________"
                    +"________________________________________________"  ); 

                
            } catch (Exception ex) { ex.printStackTrace(); }
        }
        /**
         * Method RUN to be executed when thread.start() is executed
         */
     //  public int userPort(int i)
       {
    	   
      //     return hash.get(i);
       }
       
       
       
       
       
        public void run() {
            String message;
            try {
                while ((message = reader.readLine()) != null) {
                	if(verbose) System.out.println("coded " + message); 
                	//message  = ProEncDec(false, message);
                    result.append("message received " + message + "\n");
                   
                    StringTokenizer tok1 = new StringTokenizer(message," ", false);
                    tok1.nextToken();
                    tok1.nextToken();
                    tok1.nextToken();
                    System.out.println(tok1.nextToken());
                    
                    
                    tellEveryone(message);
                    
                    	 
                    
                    
                }
            } catch (Exception ex) { ex.printStackTrace(); }
        }
    }


	public void windowOpened(WindowEvent e) { }
	public void windowClosing(WindowEvent e) { System.exit(1); }
	public void windowClosed(WindowEvent e) { }
	public void windowIconified(WindowEvent e) { }
	public void windowDeiconified(WindowEvent e) { }
	public void windowActivated(WindowEvent e) { }
	public void windowDeactivated(WindowEvent e) { }
	
}
